% clc;clear all;
twpi = 2*pi;
derad = pi/180;
j = sqrt(-1);
M1 = 6;%x轴阵元数
M2 = 6;%y轴阵元数
kelm = M1+M2-1;%实际阵元数
c = 1500;%预计声速（m/s）
f = 1e4;%载波频率（Hz）
lamda0 = c/f;
dd = lamda0/2;%阵元间距
d1 = 0:1:M1;%Nested阵
d2 = 0:1:M2;%Nested阵
d1 = d1*dd;
d2 = d2*dd;
derta = 90;%交叉线阵的夹角
theta = 30;
snr = -10:1:10;
SNR = 10.^(snr/10);
snap = 200;%采样数
CRB = 0.5./(snap*SNR)*(c./(twpi*f)).^2./(cos(theta*derad)^2*sum(d1.^2)+cos((theta-derta)*derad)^2*sum(d2.^2));
CRB = sqrt(CRB);
h1 = semilogy(snr,CRB,'k-.');
set(h1,'Linewidth',1.0)
xlabel('SNR(dB)')
ylabel('Cramer-Rao Bound(\circ)')
xlim([-10 10])
ylim([1e-5 1])


hh = legend('Cross-linear Nested Array          (6\times2 - 1)    \delta=45\circ',...
            'Cross-linear Nested Array          (6\times2 - 1)    \delta=90\circ',...
            'Uniform Linear Array                  (11\times1)',...
            'Nested Linear Array                   (11\times1)',...
            'L-shaped Uniform Linear Array  (6\times2 - 1)');
set(hh,'FontSize',8);
set(hh,'box','off');

% hold on