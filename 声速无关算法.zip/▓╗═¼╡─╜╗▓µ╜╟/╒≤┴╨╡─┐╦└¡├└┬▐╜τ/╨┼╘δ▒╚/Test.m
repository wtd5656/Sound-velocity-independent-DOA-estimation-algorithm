clc;clear all;
twpi = 2*pi;
derad = pi/180;
j = sqrt(-1);
M1 = 6;%x轴阵元数
M2 = 6;%y轴阵元数
kelm = M1+M2-1;%实际阵元数
c = 1500;%预计声速（m/s）
f = 1e4;%载波频率（Hz）
lamda0 = c/f;
dd = lamda0/2;%阵元间距
d1 = [1:M1/2,(M1/2+1):(M1/2+1):(M1/2+1)*M1/2]-1;%Nested阵
d2 = [1:M2/2,(M2/2+1):(M2/2+1):(M2/2+1)*M2/2]-1;%Nested阵
d1 = d1*dd;
d2 = d2*dd;
derta = 10:1:80;%交叉线阵的夹角
theta = 60;
snr = 0;
SNR = 10^(snr/10);
snap = 200;%采样数
CRB = 0.5*(c/(twpi*f*SNR))^2./(cos(theta*derad)^2*sum(d1.^2)+cos((theta-derta)*derad).^2*sum(d2.^2));
CRB = sqrt(CRB);
h1 = semilogy(derta,CRB,'-.');
set(h1,'Linewidth',1.0)