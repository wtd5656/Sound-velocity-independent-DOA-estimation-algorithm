% clc;clear all
derta = 10:5:80;%交叉线阵的夹角
h=plot(derta,ERROR,'--*');
grid on
set(h,'Linewidth',1.2)
xlabel('\delta(\circ)')
ylabel('RMSE(\circ)')
hold on
hh = legend('SNR=0dB Snap=200',...
            'SNR=5dB Snap=200',...
            'SNR=10dB Snap=200',...
            'SNR=5dB Snap=300',...
            'SNR=5dB Snap=400');
set(hh,'FontSize',8);
set(hh,'box','off');