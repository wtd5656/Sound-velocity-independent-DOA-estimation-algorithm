clc;clear all;
twpi = 2*pi;
derad = pi/180;
j = sqrt(-1);
M1 = 6;%x轴阵元数
M2 = 6;%y轴阵元数
kelm = M1+M2-1;%实际阵元数
c = 1500;%预计声速（m/s）
f = 1e4;%载波频率（Hz）
fs = 2*f;%采样频率（Hz）
lamda0 = c/f;
dd = lamda0/2;%阵元间距
d1 = [1:M1/2,(M1/2+1):(M1/2+1):(M1/2+1)*M1/2]-1;%Nested阵
d2 = [1:M2/2,(M2/2+1):(M2/2+1):(M2/2+1)*M2/2]-1;%Nested阵
dof1 = (M1*M1-2)/2+M1;%阵列自由度
dof2 = (M2*M2-2)/2+M2;%阵列自由度
D1 = zeros(1,M1*M1);
D2 = zeros(1,M2*M2);
for m=1:M1
    D1(1,(m-1)*M1+1:m*M1) = d1-d1(m);
end
D1 = D1+(dof1+1)/2;
for m=1:M2
    D2(1,(m-1)*M2+1:m*M2) = d2-d2(m);
end
D2 = D2+(dof2+1)/2;
d1 = d1*dd;
d2 = d2*dd;
derta = 10:1:80;%交叉线阵的夹角
theta = 60;
FF = 1000;
snr = 0;
SNR = 10^(snr/10);
snap = 200;%采样数
ERROR = zeros(1,length(derta));
for nn=1:length(derta)
    for ff=1:FF
        iwave = 1;%信源数
        theta_y = theta-derta(nn);
        t = [0:snap-1]/fs;%采样时长
        c_real = 1520;%实际声速（m/s）
        LAMDA = c_real/f;%实际波长（m）
        A1 = exp(-j*twpi*d1'*sin(theta*derad)/LAMDA);%x轴方向向量
        A2 = exp(-j*twpi*d2'*sin(theta_y*derad)/LAMDA);%y轴方向向量
        A = [A1;A2(2:end,:)];
        inx = randi([0,15],iwave,snap);
        Amp = qammod(inx,16);%调幅
        S = Amp.*exp(j*twpi*(f*ones(iwave,1)*t+rand));
        %%%%%接收数据%%%%%
        Z = awgn(A*S,snr,'measured');
        X = Z(1:M1,:);
        Y = Z([1,M1+1:end],:);
        Rx = X*X'/snap;
        Ry = Y*Y'/snap;
        zx= reshape(Rx,M1*M1,1);%转换为向量形式，成单快拍形式
        zxx= zeros(dof1,1);
        %%%%%构造虚拟单快拍接收矢量：排序去冗余%%%%%
        [loc,index] = sort(D1);
        ztemp = zeros(length(D1),1);
        for row = 1:length(D1)
            ztemp(row,1) = zx(index(row),1);
        end
        rm = 1;
        count = zeros(1,dof1);
        for r=1:length(D1)
            if(loc(r)~=rm)
                rm = rm+1;
            end
            count(rm) = count(rm)+1;
            zxx(rm) = zxx(rm)+ztemp(r);
        end
        for r=1:dof1
            zxx(r) = zxx(r)/count(r);
        end
        zy = reshape(Ry,M2*M2,1);%转换为向量形式，成单快拍形式
        zyy = zeros(dof2,1);
        %%%%%构造虚拟单快拍接收矢量：排序去冗余%%%%%
        [loc,index] = sort(D2);
        ztemp = zeros(length(D2),1);
        for row = 1:length(D2)
            ztemp(row,1) = zy(index(row),1);
        end
        rm = 1;
        count = zeros(1,dof2);
        for r=1:length(D2)
            if(loc(r)~=rm)
                rm = rm+1;
            end
            count(rm) = count(rm)+1;
            zyy(rm) = zyy(rm)+ztemp(r);
        end
        for r=1:dof2
            zyy(r) = zyy(r)/count(r);
        end
        %%%%%分别构建Teoplitz矩阵%%%%%%
        Mtp = (dof1+1)/2;
        Rxx = zeros(Mtp,Mtp);
        Ryy = zeros(Mtp,Mtp);
        for n=1:Mtp
            Rxx(:,n) = zxx(Mtp-n+1:2*Mtp-n);
            Ryy(:,n) = zyy(Mtp-n+1:2*Mtp-n);
        end
        [Ev,D] = eig(Rxx);
        [~,I] = sort(diag(D));%从小到大
        Ev = Ev(:,I);
        Es = Ev(:,end-iwave+1:end);
        EX = Es(1:Mtp-1,:);
        EY = Es(2:end,:);
        FAI_LS = pinv(EX)*EY;%LS_ESPRIT
        [T,LAMx] = eig(FAI_LS);
        LAMx = diag(LAMx);
        [Lx,I] = sort(angle(LAMx),'ascend');
        [Ev,D] = eig(Ryy);
        [~,I] = sort(diag(D));%从小到大
        Ev = Ev(:,I);
        Es = Ev(:,end-iwave+1:end);
        EX = Es(1:Mtp-1,:);
        EY = Es(2:end,:);
        FAI_LS = pinv(EX)*EY;%LS_ESPRIT
        [T,LAMy] = eig(FAI_LS);
        LAMy = diag(LAMy);
        [Ly,I] = sort(angle(LAMy));
        doa = acot(cot(derta(nn)*derad)-angle(LAMy)./(angle(LAMx)*sin(derta(nn)*derad)))/derad;
        doa = sort(doa);
        ERROR(nn) = ERROR(nn)+abs(doa-theta)^2;
    end
end
ERROR = sqrt(ERROR/FF);
save('TVI_ESPRIT_5db_400.mat','ERROR')
h1=semilogy(derta,ERROR,'-*');
grid on
set(h1,'Linewidth',1.0)
xlabel('\delta(\circ)')
ylabel('RMSE(\circ)')
xlim([10 80])
ylim([1e-4 10])
hold on

CRB = 0.5/(snap*SNR)*(c_real/(twpi*f))^2./(cos(theta*derad)^2*sum(d1.^2)+cos((theta-derta)*derad).^2*sum(d2.^2));
CRB = sqrt(CRB);

h2 = semilogy(derta,CRB,'-.');
set(h2,'Linewidth',1.0)

hold on
h3 = line([theta theta],[1e-4 10],'Color','k','LineWidth',0.05,'LineStyle','--');

hh=legend('SNR=0dB, Snapshot=200, \theta=60\circ','CRB','Direction of Arrival')
set(hh,'FontSize',8);
set(hh,'box','off');