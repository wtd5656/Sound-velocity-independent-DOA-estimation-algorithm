% clc;clear all;
derta_c = -20:5:20;
h = plot(derta_c,ERROR,'-^');
% delete(h)
set(h,'Linewidth',0.8)
xlabel('\Delta{c}(m/s)')
ylabel('RMSE(\circ)')
grid on
xlim([-20 20])
ylim([0 0.5])
set(gca,'XTick',[-20:5:20])
set(gca,'YTick',[0:0.05:0.5])
set(gca,'yTicklabel',{'0','0.05','0.10','0.15','0.20','0.25','0.30','0.35','0.40','0.45','0.50'})
hold on
h1 = plot(derta_c,RMSE_c,'-o','Color','r','Linewidth',1);
hh = legend('TLS-ESPRIT       (11\times1)',...
            'GLS-ESPRIT      (11\times1)',...
            'SS-ESPRIT         (11\times1)',...
            'VI-ESPRIT       (6\times2 - 1)',...
            'TVI-ESPRIT     (6\times2 - 1)    \delta=90\circ' ,...
            'TVI-ESPRIT     (6\times2 - 1)    \delta=45\circ' ,...
            'The theoretical error caused by velocity error');
set(hh,'FontSize',8,'Times New Roman');
set(hh,'box','off');