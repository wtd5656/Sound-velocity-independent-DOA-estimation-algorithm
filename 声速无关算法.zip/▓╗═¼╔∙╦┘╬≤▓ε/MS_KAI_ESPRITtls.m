clc;clear all;
twpi = 2*pi;
derad = pi/180;
j = sqrt(-1);
M = 11;%x����Ԫ��
c = 1500;%Ԥ�����٣�m/s��
f = 1e4;%�ز�Ƶ�ʣ�Hz��
fs = 2*f;%����Ƶ�ʣ�Hz��
lamda0 = c/f;
dd = lamda0/2;%��Ԫ���
d = 0:dd:(M-1)*dd;
theta = 30;
snr = 10;
snap = 200;%������
FF = 1000;
derta_c = -20:5:20;
ERROR = zeros(1,length(derta_c));
for nn=1:length(derta_c)
    for ff=1:FF
        iwave = 1;%��Դ��
        t = [0:snap-1]/fs;%����ʱ��
        c_real = c+derta_c(nn);%ʵ�����٣�m/s��
        LAMDA = c_real/f;
        A = exp(j*twpi*d'*sin(theta*derad)/LAMDA);%x�᷽������
        inx = randi([0,15],iwave,snap);
        Amp = qammod(inx,16);%����
        S = Amp.*exp(j*twpi*(f*ones(iwave,1)*t+rand));
        %%%%%��������%%%%%
        X = awgn(A*S,snr,'measured');
        Z = [X(1:M-1,:);X(2:M,:)];
        Rz = Z*Z'/snap;
        [Ev,D] = eig(Rz);
        [~,I] = sort(diag(D));%��С����
        Ev = Ev(:,I);
        Es = Ev(:,end-iwave+1:end);
        EX = Es(1:M-1,:);
        EY = Es(M:end,:);
        EXY = [EX';EY']*[EX EY];
        [E,DD] = eig(EXY);
        E12 = E(1:iwave,1:iwave);
        E22 = E(iwave+1:end,1:iwave);
        FAI_TLS = -E12*pinv(E22);%TLS_ESPRIT
        % FAI_TLS = pinv(EX)*EY;%LS_ESPRIT
        [T,LAM] = eig(FAI_TLS);
        LAM = diag(LAM).';
        doa_ini = sort(asin(angle(LAM)*lamda0/(twpi*dd))*180/pi);
        MSE_init = sum(abs(doa_ini - theta));
        doa_temp = doa_ini;
        %%%%%ִ�жಽ����%%%%%
        iter = iwave;
        mu = 0:0.05:1;
        U = zeros(1,length(mu));
        doa_t = zeros(iwave,length(mu));
        for n=1:iter
            A_in = exp(j*twpi*d'*sin(doa_temp*derad)/lamda0);%x�᷽������
            A_i = [A_in(1:M-1,:);A_in(2:M,:)];
            Q_A = A_i*(A_i'*A_i)^(-1)*A_i';
            Q_Ai = eye(2*M-2)-Q_A;
            V = Q_A*Rz*Q_Ai;
            for mm=1:length(mu)
                R_iter = Rz - mu(mm)*(V+V');
                doa_t(:,mm) = TLS_ESPRIT_F(R_iter,iwave,M,lamda0).';
                B_in = exp(j*twpi*d'*sin(doa_t(:,mm).'*derad)/lamda0);
                B_i = [B_in(1:M-1,:);B_in(2:M,:)];
                Q_B = B_i*(B_i'*B_i)^(-1)*B_i';
                Q_Bi = eye(2*M-2)-Q_B;
                U(mm) = det(Q_B*Rz*Q_B+trace(Q_Bi*Rz)/(M-iwave)*Q_Bi);
            end
            [~,ind] = min(U);
            doa_temp(n) = doa_t(n,ind(1));
        end
        doa_iter = doa_temp;
        doa = doa_iter;
        ERROR(nn) = ERROR(nn)+abs(doa-theta).^2;
    end
end
ERROR = sqrt(ERROR/FF);
save('MS_KAI_ESPRIT.mat','ERROR')