% clc;clear all;
snap = 100:100:800;
h = semilogy(snap,ERROR,'-^');
% delete(h1)
set(h,'Linewidth',0.8)
xlabel('The number of snapshots')
ylabel('RMSE(\circ)')
grid on
xlim([100 800])
ylim([1e-4 10])
% set(gca,'XTick',[100:100:800])
% set(gca,'YTick',[0:0.1:0.5])
hold on

% hh = legend('LS-ESPRIT       (11\times1)',...
%             'TLS-ESPRIT (11\times1)',...
%             'GLS-ESPRIT      (11\times1)');
% set(hh,'FontSize',8);
% set(hh,'box','off');

% h1 = plot(snap,RMSE_c*ones(1,length(snap)),'-o','Color','r','Linewidth',1.2)

hh = legend('TLS-ESPRIT       (11\times1)',...
            'GLS-ESPRIT      (11\times1)',...
            'SS-ESPRIT         (11\times1)',...
            'VI-ESPRIT       (6\times2 - 1)',...
            'TVI-ESPRIT     (6\times2 - 1)    \delta=90\circ' ,...
            'TVI-ESPRIT     (6\times2 - 1)    \delta=45\circ');
set(hh,'FontSize',8);
set(hh,'box','off');