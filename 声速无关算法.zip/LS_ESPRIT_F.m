function [ doa ] = LS_ESPRIT_F( Rx ,iwave,M,lamda0 )
twpi = 2*pi;
dd = lamda0/2;%��Ԫ���
[Ev,D] = eig(Rx);
[~,I] = sort(diag(D));%��С����
Ev = Ev(:,I);
Es = Ev(:,end-iwave+1:end);
EX = Es(1:M-1,:);
EY = Es(2:end,:);
FAI_LS = pinv(EX)*EY;%LS_ESPRIT
[T,LAM] = eig(FAI_LS);
LAM = diag(LAM).';
doa = sort(asin(angle(LAM)*lamda0/(twpi*dd))*180/pi);


end

