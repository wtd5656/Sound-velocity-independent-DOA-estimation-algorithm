function [receive_x,receive_y] = get_Rev(signal,sensor,sample,P)
%GET_REV
%   ����δ���������ŵĽ����ź�?
    source = get_S(signal,sample);
    [Ax,Ay] = get_Axy(signal,sensor);
    if nargin==3
        receive_x = Ax*source;
        receive_y = Ay*source;
    elseif nargin==4
        % tau is the delay time; p is the number of delayed outputs;
        tau = 0.8/max(signal.f)/(P-1);
%         tau = 1/80000;
        Phi = diag(exp(-1i*2*pi*tau*signal.f));
        Mx = sensor.x;
        receive_x = zeros(P*Mx, sample.snapshot);
        for ii = 1:P
            receive_x((ii-1)*Mx+(1:Mx),:) = Ax*Phi^(ii-1)*source;
        end
        receive_y = Ay*source;
    else
        error('argin error');
    end
end