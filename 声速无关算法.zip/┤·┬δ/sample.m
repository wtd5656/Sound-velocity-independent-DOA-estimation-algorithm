classdef sample

    properties
        fs;
        snapshot;
        snr;
    end
    
    methods
        function obj=sample(fs,snapshot,snr)
            obj.fs=fs;
            obj.snapshot=snapshot;
            obj.snr=snr;
            % obj.snr=10^(snr/10);
        end
    end
    
end