function [doa] = ESPRIT_AF(rev_x,signal,sensor)
    R = rev_x * rev_x'; % (M*P) * (M*P)
    M = sensor.x;
    K = length(signal.az);
    [temp,~] = size(R);
    P = temp/M;
    tau = 0.8/max(signal.f)/(P-1);
%     tau = 1/80000;
    
    % estimate f
    [V, D] = eig(R);
    [~,ind] = sort(real(diag(D)),'descend');
    V = V(:,ind);
    ES = V(:,1:K); % (M*P) * K
    ES1 = ES(1:(P-1)*M,:);
    ES2 = ES(M+1:P*M,:);
    fai_est = pinv(ES1)*ES2; % K * K
    [V1, D1] = eig(fai_est); 
    f_est = -angle(diag(D1))/(2*pi*tau);
%     disp(f_est);
    
    % estimate DOA
    EC0 = ES * V1; % (M*P) * K
    EC = EC0;
    for ii = 1:M
        for jj = 1:P
            EC((ii-1)*P+jj,:) = EC0((jj-1)*M+ii,:);
        end
    end
    EC1 = EC(1:(M-1)*P,:);
    EC2 = EC(P+1:M*P,:);
    C1 = pinv(EC1)*EC2;
    D2 = eig(C1);
    doa = acos(-signal.SV*angle(D2)./(2*pi*f_est*sensor.interval))*180/pi;
    doa = sort(doa)';
end