% d is the 3*K 
% r is the pos of sensors on x/y axis; 3*K [x[1,K];y[1:K];z[1:k]];
% c is the actual sound velocity 1*K;
% f is the k source signal's frequency
function [A]=get_A(d,r,c,f)
    K=length(c);
    [~,M]=size(r);
    A=zeros(M,K);
    for k=1:K
        for m=1:M
            temp=d(:,k)'*r(:,m)/c(k);
            A(m,k)=exp(-1i*2*pi*f(k)*temp); % ?????????? exp(-?) or exp(+?)
        end
    end
end