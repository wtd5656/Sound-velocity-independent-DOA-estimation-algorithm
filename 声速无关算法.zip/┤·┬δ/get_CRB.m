function [CRB]=get_CRB(signal,sensor,sample)
    M = sensor.x + sensor.y;
    K = length(signal.az);
    N = sample.snapshot;
    
    source = get_S(signal,sample);
    Rss = source*source'/N;
    Rss = diag(Rss);

    r = zeros(3,M);
    r(1,1:sensor.x) = sensor.interval*(0:sensor.x-1);
    r(1,sensor.x+(1:sensor.y)) = sensor.interval*(0:sensor.y-1)*cos(sensor.delta);
    r(2,sensor.x+(1:sensor.y)) = sensor.interval*(0:sensor.y-1)*sin(sensor.delta);
    
    [Ax,Ay] = get_Axy(signal,sensor);
    A = [Ax;Ay];
    temp = zeros(1,K);
    for kk = 1:K
        for mm = 1:M
            temp(kk) = temp(kk) + A(mm,kk)'*A(mm,kk)*(4*pi^2*signal.f(kk)^2/(signal.v(kk)^2))*(r(2,mm)*cos(signal.az(kk))-r(1,mm)*sin(signal.az(kk)))^2;
        end
    end
    snr = 10^(sample.snr/10);
    fisher = 2*N*snr*real(temp.*Rss);
    CRB = 1./fisher;
end