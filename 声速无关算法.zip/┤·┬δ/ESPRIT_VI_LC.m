function [doa] = ESPRIT_VI_LC(rev_x,rev_y,signal,sensor)
    % doa DOA���ƽ����Ϊ������
    sensor_num = sensor.x;
    signal_num = length(signal.az);
    Rxy = rev_x * rev_y';
    Rxy1 = Rxy(:, 1 : sensor_num - 1);
    Rxy2 = Rxy(:, 2 : sensor_num);
    R = [Rxy1; Rxy2];
    [U,~,~] = svd(R);
    U1 = U(:, 1 : signal_num);
    % U2 = U(:, signal_num + 1 :2 * sensor_num);
    Ux1 = [U1(1 : sensor_num - 1, :); U1(sensor_num + 1  : 2 * sensor_num - 1, :)];
    Ux2 = [U1(2  : sensor_num, :);U1(sensor_num + 2 : 2 * sensor_num, :)];
    [T,D] = eig(pinv(Ux1) * Ux2);
    D = diag(D);
    ank1 = angle(D);
    B = U1 * T;
    Z = zeros(signal_num);
    for ss = 1 : signal_num
        Z(ss, ss) = B(1,ss) * conj(B(sensor_num + 1,ss));
    end
    ank2 = angle(diag(Z));
%     doa = atan( ank2./(ank1*sin(sensor.delta))-cot(sensor.delta)) / pi * 180;
    doa = atan(abs(ank2./(ank1*sin(sensor.delta))-cot(sensor.delta))) /pi * 180;
    doa = sort(doa.');
end