classdef sensor
    
    properties
        x; % sensor number on the x-axis
        y; % sensor number on the y-axis
        delta; % cross angle
        interval; % interval
    end
    
    methods
        function obj=sensor(x,y,delta,interval)
            obj.x=x;
            obj.y=y;
            obj.delta=delta*pi/180;
            obj.interval=interval;
        end
    end
    
end