function [source] = get_S(signal,sample)
    K=length(signal.az);
    source=zeros(K,sample.snapshot);
    n=1:sample.snapshot;
    for ii=1:K
        source(ii,:)=exp(1i*2*pi*signal.f(ii).*n/sample.fs);
    end
end