classdef signal

    properties
        v;  % sound velocity
        f;  % frequency  
        az; % azimuth
        ele; % elevation 
    end
    properties (Constant)
        SV=1500; % standard=1500m/s
        DIS=1000;  % distance
        ATTENUATION=false;  % attenuation
    end
    
    methods
        function obj=signal(v,f,az,ele)
            if nargin==3
                obj.az=az*pi/180;
                obj.ele=pi/2*ones(1,length(az));
                obj.v=v;
                obj.f=f;
            elseif nargin==4
                obj.az=az*pi/180;
                obj.ele=ele*pi/180;
                obj.v=v;
                obj.f=f; 
            else 
                error('argin error');
            end
        end
    end
    
end