clear;clc; format long; addpath(genpath('ms'));
%% conclusion
% MS-KAI-ESPRIT�㷨�Զ���Դδ֪���ٻ�����ϴ���
% ����ȥ���ٵ��㷨���ܽϺõ��������ٵ�Ӱ�죻
% VI-LC�ڵ������ʱ�нϺõ�Ч����VI-TLS�ڸ������ʱ�кܺõ�Ч����������ȥ���٣����ܽ�������������Ӱ�죻

%% init
save_button = 0;
velocity_button = 1475;
fig_button = 0; fig_x = 600; fig_y = 200; fig_w = 430; fig_h = 360;

sensor_number = 10; SNR = 0;
simulation_num = 200; method_num = 8;
sig2_1500 = signal([1500,1500],[15000,16000],[30,60],[90,90]);
sig2_1475 = signal([1475,1475],[15000,16000],[30,60],[90,90]);
% sig4_1500 = signal(1500*ones(1,4),[15000,16000,17000,18000],[30,40,50,60],90*ones(1,4));
% sig4_1475 = signal(1475*ones(1,4),[15000,16000,17000,18000],[30,40,50,60],90*ones(1,4));
% sig_1500 = sig4_1500; sig_1475 = sig4_1475;
sig_1500 = sig2_1500; sig_1475 = sig2_1475;
if(velocity_button==1500); sig = sig_1500; else; sig = sig_1475; end
% sig1_1500 = signal(1500,14900,30,90);
% sig1_1475 = signal(1475,14900,30,90);
% sig3_1500 = signal([1500,1500,1500],[15000,16000,17000],[30,50,70],[90,90,90]);
% sig3_1475 = signal([1475,1475,1475],[15000,16000,17000],[30,50,70],[90,90,90]);

signal_num = length(sig.az);
sen = sensor(sensor_number,sensor_number,90,0.05);  % x; y; cross angle; interval;
samp = sample(4e4,200,SNR); % fs; snapshots; snr(dB)

% M 10:10:60        L=200
% t 0.070 0.120 0.139 0.183 0.225 0.360
% L 50:50:300       N=20
% t 0.100 0.110 0.112 0.125 0.126 0.128

%% rmse versus delta
snr = 0;
doa = zeros(method_num,signal_num);
rmse = zeros(method_num,length(snr));

% M 10:10:60        L=200
% t 1.819 6.744 12.032 20.541 29.898 43.383
% L 50:50:300       N=20
% t 6.159 6.492 6.619 6.701 6.758 6.791
% profile on
% method_num = 1; 
% sen.x = sensor_number; sen.y = sensor_number;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     [receive_x,receive_y] = get_Rev(sig,sen,samp);
%     rmse_temp = zeros(1,signal_num);
%     for jj = 1:simulation_num
%         [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
%         doa = ESPRIT_MS_KAI(rev_x,sig,sen);
%         rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
%     end
%     rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
%     disp(doa);
% end
% profile viewer


% M 10:10:60        L=200
% t 0.271 0.439 0.714 1.010 1.384 2.075
% L 50:50:300       N=20
% t 0.434 0.453 0.456 0.458 0.459 0.464
% profile on
% method_num = 8; 
% sen.x = sensor_number; sen.y = sensor_number;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     [receive_x,receive_y] = get_Rev(sig,sen,samp,3);
%     rmse_temp = zeros(1,signal_num);
%     for jj = 1:simulation_num
%         [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
%         doa = ESPRIT_AF(rev_x,sig,sen);
%         rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
%     end
%     rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
%     disp(doa);
% end
% profile viewer


% 
% M 10:10:60        L=200
% t 0.039 0.150 0.213 0.267 0.319 0.381
% L 50:50:300       N=20
% t 0.111 0.125 0.130 0.135 0.139 0.149
profile on
method_num = 2;
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(snr)
    samp.snr = snr(ii);
    [receive_x,receive_y] = get_Rev(sig,sen,samp);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = ESPRIT_TLS(rev_x,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end
profile viewer
% 

% M 10:10:60        L=200
% t 0.092 0.437 0.689 1.866 3.058 4.272
% L 50:50:300       N=20
% t 0.440 0.448 0.451 0.459 0.460 0.465
% profile on
% method_num = 3;
% sen.x = sensor_number; sen.y = sensor_number;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     [receive_x,receive_y] = get_Rev(sig,sen,samp);
%     rmse_temp = zeros(1,signal_num);
%     for jj = 1:simulation_num
%         [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
%         doa = MUSIC_Root(rev_x,sig,sen);
%         rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
%     end
%     rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
%     disp(doa);
% end
% profile viewer
% 
% method_num = 4;
% sen.x = sensor_number; sen.y = sensor_number;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     rmse(method_num,ii) = rmse_es(sig);
% end
% 
% M 10:10:60        L=200
% t 0.068 0.120 0.139 0.183 0.225 0.360
% L 50:50:300       N=20
% t 0.100 0.110 0.112 0.125 0.126 0.128
% profile on
% method_num = 5;
% sen.x = sensor_number/2; sen.y = sensor_number/2;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     [receive_x,receive_y] = get_Rev(sig,sen,samp);
%     rmse_temp = zeros(1,signal_num);
%     for jj = 1:simulation_num
%         [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
%         doa = ESPRIT_VI_LC(rev_x,rev_y,sig,sen);
%         rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
%     end
%     rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
%     disp(doa);
% end
% profile viewer
% 
% method_num = 6;
% sen.x = sensor_number; sen.y = sensor_number;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     [receive_x,receive_y] = get_Rev(sig,sen,samp);
%     rmse_temp = zeros(1,signal_num);
%     for jj = 1:simulation_num
%         [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
%         doa = ESPRIT_VI_LC(rev_x,rev_y,sig,sen);
%         rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
%     end
%     rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
%     disp(doa);
% end
% 
% method_num = 7;
% sen.x = sensor_number/2; sen.y = sensor_number/2;
% for ii = 1:length(snr)
%     samp.snr = snr(ii);
%     temp = get_CRB(sig,sen,samp);
%     rmse(method_num,ii) = sqrt(sum(diag(temp)));
% end


%% ���湤����
if(save_button==1)
    if(velocity_button==1500)
        save('code_snr_1500');
    else
        save('code_snr_1475');
    end
end

%% plot
if(fig_button == 1)
    figure;  set (gcf,'Position',[fig_x,fig_y,fig_w,fig_h]);
    plot(snr,rmse(1,:),'-*c',...
        snr,rmse(2,:),'-^g',...
        snr,rmse(3,:),'-xb',...
        snr,rmse(8,:),'--m',...
        snr,rmse(4,:),'--k',...
        snr,rmse(5,:),'-or',...
        snr,rmse(6,:),'-sr',...
        snr,rmse(7,:)*1e2,'-sk');
    set(gca,'FontSize',8,'FontName','Fira Code Retina');
    xlabel('SNR(dB)');ylabel('RMSE(��)');
    %     axis([-5 20 0 4.5]);
    legend_1 = sprintf("MS-KAI-ESPRIT   (%d*1)",sensor_number);
    legend_2 = sprintf("TLS-ESPRIT      (%d*1)",sensor_number);
    legend_3 = sprintf("ROOT-MUSIC      (%d*1)",sensor_number);
    legend_4 = sprintf("RMSE_c           (%d*1)",sensor_number);
    legend_5 = sprintf("Proposed VI-LC  (%d*2)",sensor_number/2);
    legend_6 = sprintf("Proposed VI-LC  (%d*2)",sensor_number);
    legend_7 = sprintf("CRB(*10)        (%d*2)",sensor_number/2);
    legend_8 = sprintf("AF-ESPRIT       (%d*1)",sensor_number);
    h = legend(legend_1,legend_2,legend_3,legend_8,legend_4,legend_5,legend_6,legend_7);
    set(h,'FontSize',8); legend('boxoff');
end