function rmse = rmse_es(signal) % C is the actual velocity 
    ca = signal.v;
%     ci = 0.1*signal.f; % 2*d*f_i
%     ci = 1500*ones(1,length(signal.v));
    theta = signal.az;
    rmse = 0;
    for ii = 1:length(signal.az)
%         temp = 180/pi*acos(ci(ii)/ca(ii)*cos(theta(ii)));
        temp = 180/pi*acos(1500*cos(theta(ii))/ca(ii));
        rmse = rmse + abs(temp-signal.az(ii)*180/pi);
    end
    rmse = rmse/length(signal.az);
    
end