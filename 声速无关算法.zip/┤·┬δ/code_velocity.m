clear;clc; format long; addpath(genpath('ms'));
%% conclusion

%% init
save_button = 1;
snr_button = 0; 
velocity_button = 1500;
fig_button = 1; fig_x = 600; fig_y = 200; fig_w = 430; fig_h = 360;

if(snr_button==0); SNR=0; else; SNR=10; end
sensor_number = 10;
simulation_num = 1000; method_num = 8;
sig2_1500 = signal([1500,1500],[15000,16000],[30,60],[90,90]);
sig2_1475 = signal([1475,1475],[15000,16000],[30,60],[90,90]);
sig_1500 = sig2_1500; sig_1475 = sig2_1475;
if(velocity_button==1500); sig = sig_1500; else; sig = sig_1475; end

% sig4 = signal(1475*ones(1,4),[15500,15000,14500,14000],[30,50,40,60],90*ones(1,4));
% sig = sig4; 

signal_num = length(sig.az);
sen = sensor(sensor_number,sensor_number,90,0.05);  % x; y; cross angle; interval;
samp = sample(4e4,200,SNR); % fs; snapshots; snr(dB)

%% rmse versus delta
velocity = 1450:10:1550;
doa = zeros(method_num,signal_num);
rmse = zeros(method_num,length(velocity));

method_num = 1; 
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    [receive_x,receive_y] = get_Rev(sig,sen,samp);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = ESPRIT_MS_KAI(rev_x,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end

method_num = 8; 
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    [receive_x,receive_y] = get_Rev(sig,sen,samp,3);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = ESPRIT_AF(rev_x,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end

method_num = 2;
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    [receive_x,receive_y] = get_Rev(sig,sen,samp);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = ESPRIT_TLS(rev_x,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end

method_num = 3;
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    [receive_x,receive_y] = get_Rev(sig,sen,samp);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = MUSIC_Root(rev_x,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end

method_num = 4;
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    rmse(method_num,ii) = rmse_es(sig);
end

method_num = 5;
sen.x = sensor_number/2; sen.y = sensor_number/2;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    [receive_x,receive_y] = get_Rev(sig,sen,samp);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = ESPRIT_VI_LC(rev_x,rev_y,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end

method_num = 6;
sen.x = sensor_number; sen.y = sensor_number;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    [receive_x,receive_y] = get_Rev(sig,sen,samp);
    rmse_temp = zeros(1,signal_num);
    for jj = 1:simulation_num
        [rev_x,rev_y] = set_Rev(receive_x,receive_y,samp);
        doa = ESPRIT_VI_LC(rev_x,rev_y,sig,sen);
        rmse_temp = rmse_temp + diag((doa - sort(sig.az)*180/pi)'*(doa - sort(sig.az)*180/pi))';
    end
    rmse(method_num,ii) = mean(sqrt(rmse_temp/simulation_num));
    disp(doa);
end

method_num = 7;
sen.x = sensor_number/2; sen.y = sensor_number/2;
for ii = 1:length(velocity)
    sig.v = velocity(ii)*ones(1,signal_num);
    temp = get_CRB(sig,sen,samp);
    rmse(method_num,ii) = sqrt(sum(diag(temp)));
end


%% ���湤����
if(save_button==1)
    if(SNR==10); save('code_velocity_10'); else; save('code_velocity_0'); end
end

%% plot
if(fig_button==1)
    velocity_plot = velocity - 1500;
    figure;  set (gcf,'Position',[fig_x,fig_y,fig_w,fig_h]);
    plot(    velocity_plot,rmse(1,:),'-*c',...
        velocity_plot,rmse(2,:),'-^g',...
        velocity_plot,rmse(3,:),'-xb',...
        velocity_plot,rmse(8,:),'--m',...
        velocity_plot,rmse(4,:),'--k',...
        velocity_plot,rmse(5,:),'-or',...
        velocity_plot,rmse(6,:),'-sr',...
        velocity_plot,rmse(7,:)*10,'-sk');
    set(gca,'FontSize',8,'FontName','Fira Code Retina');
    xlabel('\Deltac(m/s)');ylabel('RMSE(��)');
    legend_1 = sprintf("MS-KAI-ESPRIT   (%d*1)",sensor_number);
    legend_2 = sprintf("TLS-ESPRIT      (%d*1)",sensor_number);
    legend_3 = sprintf("ROOT-MUSIC      (%d*1)",sensor_number);
    legend_4 = sprintf("RMSE_c           (%d*1)",sensor_number);
    legend_5 = sprintf("Proposed VI-LC  (%d*2)",sensor_number/2);
    legend_6 = sprintf("Proposed VI-LC  (%d*2)",sensor_number);
    legend_7 = sprintf("CRB(*10)        (%d*2)",sensor_number/2);
    legend_8 = sprintf("AF-ESPRIT       (%d*1)",sensor_number);
    h = legend(legend_1,legend_2,legend_3,legend_8,legend_4,legend_5,legend_6,legend_7);
    set(h,'FontSize',8); legend('boxoff');
    ax = gca; ax.XTick = (-50:20:50);
end