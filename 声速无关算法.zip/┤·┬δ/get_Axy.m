function [Ax,Ay]=get_Axy(signal,sensor)
    K = length(signal.f);
    Mx = sensor.x;
    My = sensor.y;
    d=zeros(3,K);
    for k=1:K
        phi=signal.az(k);
        theta=signal.ele(k);
        d(:,k)=[cos(phi)*sin(theta); sin(phi)*sin(theta); cos(theta)];
    end
    rx=zeros(3,Mx);
    rx(1,:)=sensor.interval*(0:sensor.x-1);
    ry=zeros(3,My);
    ry(1,:)=sensor.interval*(0:sensor.y-1)*cos(sensor.delta);
    ry(2,:)=sensor.interval*(0:sensor.y-1)*sin(sensor.delta);
    c = signal.v; % ���ڽ��վ�����˵��������ʵ������һ��
    f = signal.f;
    Ax = get_A(d,rx,c,f);
    Ay = get_A(d,ry,c,f);
end