clear;clc;format long;
load("code_snr_1500");
rmse(1,:)=[2.69794250578999,2.5537992862408,2.15990174392246,0.994322791285141,0.816236623011358,0.721867414130950];
if(fig_button == 1)
    figure;  set (gcf,'Position',[fig_x,fig_y,fig_w,fig_h]);
    plot(snr,rmse(1,:),'-*c',...
        snr,rmse(2,:),'-^g',...
        snr,rmse(3,:),'-xb',...
        snr,rmse(8,:),'--m',...
        snr,rmse(4,:),'--k',...
        snr,rmse(5,:),'-or',...
        snr,rmse(6,:),'-sr',...
        snr,rmse(7,:)*10,'-sk');
    set(gca,'FontSize',8,'FontName','Fira Code Retina');
    xlabel('SNR(dB)');ylabel('RMSE(��)');
    %     axis([-5 20 0 4.5]);
    legend_1 = sprintf("MS-KAI-ESPRIT   (%d*1)",sensor_number);
    legend_2 = sprintf("TLS-ESPRIT      (%d*1)",sensor_number);
    legend_3 = sprintf("ROOT-MUSIC      (%d*1)",sensor_number);
    legend_4 = sprintf("RMSE_c           (%d*1)",sensor_number);
    legend_5 = sprintf("Proposed VI-LC  (%d*2)",sensor_number/2);
    legend_6 = sprintf("Proposed VI-LC  (%d*2)",sensor_number);
    legend_7 = sprintf("CRB(*10)        (%d*2)",sensor_number/2);
    legend_8 = sprintf("AF-ESPRIT       (%d*1)",sensor_number);
    h = legend(legend_1,legend_2,legend_3,legend_8,legend_4,legend_5,legend_6,legend_7);
    set(h,'FontSize',8); legend('boxoff');
end

clear;clc;format long;
load('code_snr_1475');
rmse(1,:)=[2.59184773835201,2.47651450739222,2.30502691739406,1.17584946395377,1.04645183757552,0.99343617664212];
if(fig_button == 1)
    figure;  set (gcf,'Position',[fig_x,fig_y,fig_w,fig_h]);
    plot(snr,rmse(1,:),'-*c',...
        snr,rmse(2,:),'-^g',...
        snr,rmse(3,:),'-xb',...
        snr,rmse(8,:),'--m',...
        snr,rmse(4,:),'--k',...
        snr,rmse(5,:),'-or',...
        snr,rmse(6,:),'-sr',...
        snr,rmse(7,:)*10,'-sk');
    set(gca,'FontSize',8,'FontName','Fira Code Retina');
    xlabel('SNR(dB)');ylabel('RMSE(��)');
    %     axis([-5 20 0 4.5]);
    legend_1 = sprintf("MS-KAI-ESPRIT   (%d*1)",sensor_number);
    legend_2 = sprintf("TLS-ESPRIT      (%d*1)",sensor_number);
    legend_3 = sprintf("ROOT-MUSIC      (%d*1)",sensor_number);
    legend_4 = sprintf("RMSE_c           (%d*1)",sensor_number);
    legend_5 = sprintf("Proposed VI-LC  (%d*2)",sensor_number/2);
    legend_6 = sprintf("Proposed VI-LC  (%d*2)",sensor_number);
    legend_7 = sprintf("CRB(*10)        (%d*2)",sensor_number/2);
    legend_8 = sprintf("AF-ESPRIT       (%d*1)",sensor_number);
    h = legend(legend_1,legend_2,legend_3,legend_8,legend_4,legend_5,legend_6,legend_7);
    set(h,'FontSize',8); legend('boxoff');
end

clear;clc;format long;
load('code_velocity_0');
rmse(1,:)=[2.95084293843969,2.67782971271199,2.52416710225734,2.46569168769327,2.43808081723304,2.40530536935229,2.54467069294820,2.66676104137780,2.96483230640534,3.27049317967304,3.61637420458816];
if(fig_button==1)
    velocity_plot = velocity - 1500;
    figure;  set (gcf,'Position',[fig_x,fig_y,fig_w,fig_h]);
    plot(    velocity_plot,rmse(1,:),'-*c',...
        velocity_plot,rmse(2,:),'-^g',...
        velocity_plot,rmse(3,:),'-xb',...
        velocity_plot,rmse(8,:),'--m',...
        velocity_plot,rmse(4,:),'--k',...
        velocity_plot,rmse(5,:),'-or',...
        velocity_plot,rmse(6,:),'-sr',...
        velocity_plot,rmse(7,:)*10,'-sk');
    set(gca,'FontSize',8,'FontName','Fira Code Retina');
    xlabel('\Deltac(m/s)');ylabel('RMSE(��)');
    legend_1 = sprintf("MS-KAI-ESPRIT   (%d*1)",sensor_number);
    legend_2 = sprintf("TLS-ESPRIT      (%d*1)",sensor_number);
    legend_3 = sprintf("ROOT-MUSIC      (%d*1)",sensor_number);
    legend_4 = sprintf("RMSE_c           (%d*1)",sensor_number);
    legend_5 = sprintf("Proposed VI-LC  (%d*2)",sensor_number/2);
    legend_6 = sprintf("Proposed VI-LC  (%d*2)",sensor_number);
    legend_7 = sprintf("CRB(*10)        (%d*2)",sensor_number/2);
    legend_8 = sprintf("AF-ESPRIT       (%d*1)",sensor_number);
    h = legend(legend_1,legend_2,legend_3,legend_8,legend_4,legend_5,legend_6,legend_7);
    set(h,'FontSize',8); legend('boxoff');
    ax = gca; ax.XTick = (-50:20:50);
end

clear;clc;format long;
load('code_velocity_10');
rmse(1,:)=[3.01473188032328,1.85098080247955,1.42496976283979,0.980619261596353,0.741418903148642,0.690803057358963,0.839121329578580,1.04372169836258,1.40034919988611,1.96572195835345,3.54949792504951];
if(fig_button==1)
    velocity_plot = velocity - 1500;
    figure;  set (gcf,'Position',[fig_x,fig_y,fig_w,fig_h]);
    plot(    velocity_plot,rmse(1,:),'-*c',...
        velocity_plot,rmse(2,:),'-^g',...
        velocity_plot,rmse(3,:),'-xb',...
        velocity_plot,rmse(8,:),'--m',...
        velocity_plot,rmse(4,:),'--k',...
        velocity_plot,rmse(5,:),'-or',...
        velocity_plot,rmse(6,:),'-sr',...
        velocity_plot,rmse(7,:)*10,'-sk');
    set(gca,'FontSize',8,'FontName','Fira Code Retina');
    xlabel('\Deltac(m/s)');ylabel('RMSE(��)');
    legend_1 = sprintf("MS-KAI-ESPRIT   (%d*1)",sensor_number);
    legend_2 = sprintf("TLS-ESPRIT      (%d*1)",sensor_number);
    legend_3 = sprintf("ROOT-MUSIC      (%d*1)",sensor_number);
    legend_4 = sprintf("RMSE_c           (%d*1)",sensor_number);
    legend_5 = sprintf("Proposed VI-LC  (%d*2)",sensor_number/2);
    legend_6 = sprintf("Proposed VI-LC  (%d*2)",sensor_number);
    legend_7 = sprintf("CRB(*10)        (%d*2)",sensor_number/2);
    legend_8 = sprintf("AF-ESPRIT       (%d*1)",sensor_number);
    h = legend(legend_1,legend_2,legend_3,legend_8,legend_4,legend_5,legend_6,legend_7);
    set(h,'FontSize',8); legend('boxoff');
    ax = gca; ax.XTick = (-50:20:50);
end