% clc;clear all;
snr = -4:2:10;
h = semilogy(snr,ERROR,'-^');
% delete(h1)
set(h,'Linewidth',0.8)
xlabel('SNR(dB)')
ylabel('RMSE(\circ)')
grid on
xlim([-4 10])
ylim([1e-4 10])
hold on
% h1 = plot(snr,RMSE_c*ones(1,length(snr)),'-o','Color','r','Linewidth',1);

% hh = legend('LS-ESPRIT       (11\times1)',...
%             'TLS-ESPRIT (11\times1)',...
%             'GLS-ESPRIT      (11\times1)');
% set(hh,'FontSize',8);
% set(hh,'box','off');
% 
% hh = legend('TLS-ESPRIT       (11\times1)',...
%             'GLS-ESPRIT      (11\times1)',...
%             'SS-ESPRIT         (11\times1)',...
%             'VI-ESPRIT       (6\times2 - 1)',...
%             'TVI-ESPRIT     (6\times2 - 1)    \delta=90\circ' ,...
%             'TVI-ESPRIT     (6\times2 - 1)    \delta=45\circ');
set(hh,'FontSize',8);
% set(hh,'box','off');