clc;clear all;
twpi = 2*pi;
derad = pi/180;
j = sqrt(-1);
M = 10;%x����Ԫ��
c = 1500;%Ԥ�����٣�m/s��
f = 1e4;%�ز�Ƶ�ʣ�Hz��
fs = 2*f;%����Ƶ�ʣ�Hz��
lamda0 = c/f;
dd = lamda0/2;%��Ԫ���
d = 0:dd:(M-1)*dd;
theta = 10:10:80;
FF = 1000;
ERROR = zeros(1,length(theta));
for ii=1:length(theta)
    for ff=1:FF
        iwave = 1;%��Դ��
        snr = 0;
        snap = 200;%������
        t = [0:snap-1]/fs;%����ʱ��
        A = exp(j*twpi*d'*sin(theta(ii)*derad)/lamda0);%x�᷽������
        inx = randi([0,15],iwave,snap);
        Amp = qammod(inx,16);%����
        S = Amp.*exp(j*twpi*(f*ones(iwave,1)*t+rand));
        %%%%%��������%%%%%
        X = awgn(A*S,snr,'measured');
        Rx = X*X'/snap;
%         %%%MΪ����%%%
%         I = eye((M-1)/2);
%         J = fliplr(eye((M-1)/2));
%         QM = [I,zeros((M-1)/2,1),j*I;
%             zeros(1,(M-1)/2),sqrt(2),zeros(1,(M-1)/2);
%             J,zeros((M-1)/2,1),-j*J]/sqrt(2);
%         QM_1 = [I,j*I;J,-j*J]/sqrt(2);

        %%%MΪż��%%%
        I = eye(M/2);
        J = fliplr(eye(M/2));
        QM = [I,j*I;J,-j*J]/sqrt(2);%MΪż��
        QM_1 = [eye(M/2-1),zeros(M/2-1,1),j*eye(M/2-1);
                zeros(1,(M-2)/2),sqrt(2),zeros(1,(M-2)/2);
                fliplr(eye(M/2-1)),zeros(M/2-1,1),-j*fliplr(eye(M/2-1))]/sqrt(2);
        Jr = fliplr(eye(M));
        Tx = QM'*(Rx+Jr*conj(Rx)*Jr)*QM;
        %%%%%����QR-ESPRIT%%%%%
        [Q,R] = qr(Tx);
        U1 = R(1:iwave,1:iwave);
        U2 = R(1:iwave,iwave+1:end);
        B = -inv(U1)*U2;
        Es = [-eye(iwave),B].';
        K1=[eye(M-1) zeros(M-1,1)];
        K2=[zeros(M-1,1) eye(M-1)];
        H1=QM_1'*(K1+K2)*QM;
        H2=j*QM_1'*(K1-K2)*QM;
        Us1=H1*Es;
        Us2=H2*Es;
        FHls=pinv(Us1)*Us2; % LS-ESPRIT�㷨
        [T,LAM] = eig(FHls);
        LAM = diag(LAM).';
        an = real(2*atan(LAM));
        doa = sort(asin(an/pi)/derad);
        ERROR(ii) = ERROR(ii)+abs(doa-theta(ii));
    end
end
ERROR = ERROR/FF;
save('QR_ESPRIT.mat','ERROR')