% clc;clear all;
theta = 10:10:80;
h = semilogy(theta,ERROR,'-^');
set(h,'Linewidth',0.8)
xlabel('\theta(\circ)')
ylabel('RMSE(\circ)')
grid on
xlim([10 80])
ylim([1e-4 10])
% set(gca,'XTick',[10:10:80])
% set(gca,'YTick',[0:0.1:0.8])
hold on
% h1 = plot(theta,RMSE_c,'-o','Color','r','Linewidth',1.2)
hh = legend('TLS-ESPRIT       (11\times1)',...
            'MS-KAI-ESPRIT (11\times1)',...
            'GLS-ESPRIT      (11\times1)',...
            'SS-ESPRIT         (11\times1)',...
            'VI-ESPRIT       (6\times2 - 1)',...
            'TVI-ESPRIT     (6\times2 - 1)',...
            'TVI-ESPRIT     (11\times2 - 1)');
set(hh,'FontSize',8);
set(hh,'box','off');


% set(hh,'FontName','FixedWidth')