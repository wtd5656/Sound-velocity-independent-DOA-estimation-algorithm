function y = arccot(x)
y = acot(x);
if y < 0
    y = y + pi;
end
end

